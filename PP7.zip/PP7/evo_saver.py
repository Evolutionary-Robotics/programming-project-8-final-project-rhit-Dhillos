import numpy as np
import matplotlib.pyplot as plt
import fnn 
import ea
import environment
import agent
import matplotlib.animation as anim
import pickle

def get_distance(x1, x2, y1, y2): 
  return np.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)

# Parameters of the neural network
layers = [4, 4, 4]

# Parameters of the evolutionary algorithm
genesize = np.sum(np.multiply(layers[1:],layers[:-1])) + np.sum(layers[1:]) 
print("Number of parameters:",genesize)
popsize = 50 
recombProb = 0.5
mutatProb = 0.01
tournaments = 100*popsize 

sound = environment.SoundGradient(source=(50, 50), decay_factor=0.001)
sound_grid = sound.generate_gradient()

train_run = 0
train_num = 0

def fitnessFunction(genotype, sound_grid, train_run, train_num):
    snd_src_x = sound.source[0]
    snd_src_y = sound.source[1]
    
    a = fnn.FNN(layers)
    a.setParams(genotype)
    
    alist = []      

    alist.append(agent.Agent(20, 20, sound_grid, a))
    alist.append(agent.Agent(70, 20, sound_grid, a))
    alist.append(agent.Agent(30, 70, sound_grid, a))
    alist.append(agent.Agent(60, 60, sound_grid, a))

    # alist.append(agent.Agent(10, 10, sound_grid, a))
    # alist.append(agent.Agent(70, 30, sound_grid, a))
    # alist.append(agent.Agent(40, 60, sound_grid, a))
    # alist.append(agent.Agent(60, 90, sound_grid, a))
    
    # alist.append(agent.Agent(45, 40, sound_grid, a))
    # alist.append(agent.Agent(50, 60, sound_grid, a))
    # alist.append(agent.Agent(60, 40, sound_grid, a))
    # alist.append(agent.Agent(20, 70, sound_grid, a))
    
    total_distance_travelled = 0
    max_distance = np.sqrt(sound_grid.shape[0]**2 + sound_grid.shape[1]**2)

    agn = alist[train_num] 
    if train_run == 100:
        train_num += 1 
        train_run = 0

        
    runs = 0
    while sound_grid[agn.x, agn.y] < 0.98 and runs < 100:
        agn_x, agn_y = agn.get_position()
        # step_distance = get_distance(snd_src_x, agn_x, snd_src_y, agn_y)
        # path_distance += step_distance  # Accumulate distance for each step
        
        agn.move()  # Move the agent to the next position
        runs += 1
    
    agn_x, agn_y = agn.get_position()
    final_distance = get_distance(snd_src_x, agn_x, snd_src_y, agn_y)
    
    # total_distance_travelled += path_distance + final_distance
    total_distance_travelled +=  final_distance
 
    normalized_fitness = 1 - (total_distance_travelled/ (max_distance ))
    
    normalized_fitness = max(0, min(1, normalized_fitness))
    train_run += 1
    return normalized_fitness

# def fitnessFunction(genotype, sound_grid):
#     snd_src_x = sound.source[0]
#     snd_src_y = sound.source[1]
    
#     a = fnn.FNN(layers)
#     a.setParams(genotype)

#     alist = []      

#     alist.append(agent.Agent(20, 20, sound_grid, a))
#     alist.append(agent.Agent(70, 20, sound_grid, a))
#     alist.append(agent.Agent(30, 70, sound_grid, a))
#     alist.append(agent.Agent(60, 60, sound_grid, a))

#     # alist.append(agent.Agent(10, 10, sound_grid, a))
#     # alist.append(agent.Agent(70, 30, sound_grid, a))
#     # alist.append(agent.Agent(40, 60, sound_grid, a))
#     # alist.append(agent.Agent(60, 90, sound_grid, a))
    
#     # alist.append(agent.Agent(45, 40, sound_grid, a))
#     # alist.append(agent.Agent(50, 60, sound_grid, a))
#     # alist.append(agent.Agent(60, 40, sound_grid, a))
#     # alist.append(agent.Agent(20, 70, sound_grid, a))
    
#     total_distance_travelled = 0
#     max_distance = np.sqrt(sound_grid.shape[0]**2 + sound_grid.shape[1]**2)
    
#     for agn in alist:
#         path_distance = 0  
#         runs = 0
        
#         while sound_grid[agn.x, agn.y] < 0.98 and runs < 100:
#             agn_x, agn_y = agn.get_position()
#             step_distance = get_distance(snd_src_x, agn_x, snd_src_y, agn_y)
#             path_distance += step_distance  # Accumulate distance for each step
            
#             agn.move()  # Move the agent to the next position
#             runs += 1
        
#         agn_x, agn_y = agn.get_position()
#         final_distance = get_distance(snd_src_x, agn_x, snd_src_y, agn_y)
        
#         # total_distance_travelled += path_distance + final_distance
#         total_distance_travelled +=  final_distance

#     avg_distance_travelled = total_distance_travelled / len(alist)
    
#     normalized_fitness = 1 - (avg_distance_travelled / (max_distance ))
    
#     normalized_fitness = max(0, min(1, normalized_fitness))

#     return normalized_fitness

# Evolve
ga = ea.MGA(fitnessFunction, sound_grid, genesize, popsize, recombProb, mutatProb, tournaments, train_run, train_num)
ga.run()
ga.showFitness()

# Obtain best agent
best = int(ga.bestind[-1])
print(best)
a = fnn.FNN(layers)
a.setParams(ga.pop[best])

with open('test1.pkl', 'wb') as f:
    pickle.dump({'layers': layers,'weights': a.weights, 'biases': a.biases}, f)


# worst_final = []
# best_final = []
# avg_final = []
# layer_list = [[4, 4, 4], [4, 12, 4], [4, 36, 4], [4, 144, 4], 
#               [4, 12, 12, 4], [4, 36, 36, 4], [4, 4, 4, 4, 4, 4], [4, 12, 12, 12, 12, 4]] 
# # layer_list = [[4, 4, 4], [4, 12, 4]]
# for l in layer_list :  
  
#   print(f"layer combo: {l}")
#   layers = l
#   genesize = np.sum(np.multiply(layers[1:],layers[:-1])) + np.sum(layers[1:]) 
#   print("Number of parameters:",genesize)

#   popsize = 50 
#   recombProb = 0.5
#   mutatProb = 0.01
#   tournaments = 50*popsize
#   ga = ea.MGA(fitnessFunction, sound_grid, genesize, popsize, recombProb, mutatProb, tournaments)
#   ga.run()
#   best_final.append(ga.bestfit[-1])
#   avg_final.append(ga.avgfit[-1])
#   worst_final.append(ga.worstfit[-1])
    

# layer_str = [str(l) for l in layer_list]

# x = np.arange(len(layer_list)) 

# plt.bar(x - 0.2, best_final, width=0.2, label='Best')
# plt.bar(x, avg_final, width=0.2, label='Avg.')
# plt.bar(x + 0.2, worst_final, width=0.2, label='Worst')

# plt.xticks(x, layer_str, rotation=45, ha='right')

# plt.xlabel("Layer Configurations")
# plt.ylabel("Fitness")
# plt.title("Evolution Performance with Different Layer Configurations")
# plt.legend()

# # Show plot
# plt.tight_layout()  # Adjust layout to prevent overlap
# plt.show()


# with open('test1.pkl', 'wb') as f:
#     pickle.dump({'best': best_final,'avg': avg_final, 'worst': worst_final}, f)



# # worst_final = []
# # best_final = []
# # avg_final = []
# # gens_list = [5, 10, 25, 50, 75, 100, 125, 150, 200, 300] 
# # # gens_list = [5, 10, 25] 
# # for g in gens_list :  
# #   # Evolve
# #   print(f"gens : {g}")
# #   tournaments = g*popsize
# #   ga = ea.MGA(fitnessFunction, sound_grid, genesize, popsize, recombProb, mutatProb, tournaments)
# #   ga.run()
# #   best_final.append(ga.bestfit[-1])
# #   avg_final.append(ga.avgfit[-1])
# #   worst_final.append(ga.worstfit[-1])
    
# # plt.xticks(gens_list)
# # plt.plot(gens_list,best_final,label="Best")
# # plt.plot(gens_list, avg_final,label="Avg.")
# # plt.plot(gens_list, worst_final,label="Worst")
# # plt.xlabel("Generations")
# # plt.ylabel("Fitness")
# # plt.title("Evolution")
# # plt.legend()
# # plt.show() 


# # with open('fitness_experiments.pkl', 'wb') as f:
# #     pickle.dump({'best': best_final,'avg': avg_final, 'worst': worst_final}, f)


import numpy as np
import matplotlib.pyplot as plt
import fnn 
import ea
import environment
import agent
import matplotlib.animation as anim
import pickle

def get_distance(x1, x2, y1, y2): 
  return np.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)

# Parameters of the neural network
layers = [4, 4, 4]

# Parameters of the evolutionary algorithm
genesize = np.sum(np.multiply(layers[1:],layers[:-1])) + np.sum(layers[1:]) 
print("Number of parameters:",genesize)
popsize = 50 
recombProb = 0.5
mutatProb = 0.01
tournaments = 100*popsize 

sound = environment.SoundGradient(source=(50, 50), decay_factor=0.001)
sound_grid = sound.generate_gradient()

train_run = 0
train_num = 0

def fitnessFunction(genotype, sound_grid, x, y):
    snd_src_x = sound.source[0]
    snd_src_y = sound.source[1]

    a = fnn.FNN(layers)
    a.setParams(genotype)  
    agn = agent.Agent(x, y, sound_grid, a)
    total_distance_travelled = 0
    max_distance = np.sqrt(sound_grid.shape[0]**2 + sound_grid.shape[1]**2)
        
    runs = 0
    while sound_grid[agn.x, agn.y] < 0.98 and runs < 100:
        agn_x, agn_y = agn.get_position() 
        agn.move()  # Move the agent to the next position
        runs += 1
    
    agn_x, agn_y = agn.get_position()
    final_distance = get_distance(snd_src_x, agn_x, snd_src_y, agn_y)
    
    # total_distance_travelled += path_distance + final_distance
    total_distance_travelled +=  final_distance
 
    normalized_fitness = 1 - (total_distance_travelled/ (max_distance ))
    
    normalized_fitness = max(0, min(1, normalized_fitness))
  
    return normalized_fitness



# Evolve
agn_list = []      
pop = np.random.random((popsize,genesize))*2 - 1  

agn_list.append((20, 20))
agn_list.append((60, 20))
# agn_list.append((20, 60))
# agn_list.append((60, 60))

for al in agn_list: 
    x = al[0] 
    y = al[1]
    ga = ea.MGA(fitnessFunction, sound_grid, genesize, popsize, recombProb, mutatProb, tournaments, pop, x, y)
    ga.run() 
    best = int(ga.bestind[-1]) 
    for i in range(popsize):
        pop[i] = ga.pop[best]
    ga.showFitness() 


# Obtain best agent
best = int(ga.bestind[-1])
a = fnn.FNN(layers)
a.setParams(ga.pop[best])

with open('test1.pkl', 'wb') as f:
    pickle.dump({'layers': layers,'weights': a.weights, 'biases': a.biases}, f)


